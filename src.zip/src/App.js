import React from 'react';
import Button from './button/Button'; 
import UserProfile from './user_profile/UserProfile';
import logo from './logo.svg';
import './App.css';

function App() {
  const handleClick = () => {
    console.log('Кнопка была нажата!');
    // Здесь вы можете выполнить нужные действия при нажатии на кнопку
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        
        <Button onClick={handleClick} text="Нажми меня" />
      <UserProfile name="John Doe" age={25} email="john@example.com" />
    
      </header>
      
    </div>
  );
}

export default App;
